<?php
// Questions with multiple-choice options (C Language)
$questions = [
    [
        "question" => "What is the size of int in C (on most 32-bit systems)?",
        "options" => ["2 bytes", "4 bytes", "8 bytes", "Depends on compiler"],
        "answer" => "4 bytes"
    ],
    [
        "question" => "Which of the following is used to take input in C?",
        "options" => ["cin", "input()", "scanf()", "read()"],
        "answer" => "scanf()"
    ],
    [
        "question" => "Which header file is required for printf() and scanf()?",
        "options" => ["stdlib.h", "string.h", "stdio.h", "conio.h"],
        "answer" => "stdio.h"
    ],
    [
        "question" => "Which symbol is used to denote a pointer in C?",
        "options" => ["&", "*", "#", "%"],
        "answer" => "*"
    ],
    [
        "question" => "What is the correct format specifier for printing an integer in C?",
        "options" => ["%c", "%s", "%d", "%f"],
        "answer" => "%d"
    ],
    [
        "question" => "Which keyword is used to define a constant in C?",
        "options" => ["const", "define", "static", "final"],
        "answer" => "const"
    ],
    [
        "question" => "Which loop in C is guaranteed to execute at least once?",
        "options" => ["for", "while", "do-while", "goto"],
        "answer" => "do-while"
    ],
    [
        "question" => "What is the default return type of a function in C (if not specified)?",
        "options" => ["void", "int", "float", "char"],
        "answer" => "int"
    ],
    [
        "question" => "Which operator is used to access the value at the address of a pointer?",
        "options" => ["&", "*", "->", "."],
        "answer" => "*"
    ],
    [
        "question" => "Which of the following is not a valid storage class in C?",
        "options" => ["auto", "register", "volatile", "mutable"],
        "answer" => "mutable"
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>C Language Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form, .result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    input[type="submit"] {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    input[type="submit"]:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    echo "<div class='result'>";
    echo "<h2>Result:</h2>";
    foreach ($questions as $i => $q) {
        $userAnswer = $_POST['answer' . $i] ?? '';
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        echo "Your Answer: $userAnswer<br>";
        if ($userAnswer === $q['answer']) {
            echo "<span class='correct'>Correct (+2)</span></p>";
            $score += 2;
        } else {
            echo "<span class='incorrect'>Incorrect (0)</span><br>";
            echo "Correct Answer: {$q['answer']}</p>";
        }
    }
    echo "<h3>Total Score: $score / " . (count($questions) * 2) . "</h3>";
    echo "<a href=''>Try Again</a>";
    echo "</div>";
} else {
    // Show the quiz form
    echo "<h2>C Language Quiz</h2>";
    echo "<form method='post'>";
    foreach ($questions as $i => $q) {
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        foreach ($q['options'] as $option) {
            echo "<label class='option'>
                    <input type='radio' name='answer$i' value='$option' required> $option
                  </label>";
        }
        echo "</p>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
}
?>

</body>
</html>
