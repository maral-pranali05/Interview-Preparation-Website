<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>JavaScript Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    #quiz, #result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    button {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    button:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<h2>JavaScript Quiz</h2>

<div id="quiz"></div>
<div id="result" style="display:none;"></div>

<script>
  // Questions for JavaScript Quiz
  const questions = [
    {
      question: "Which company developed JavaScript?",
      options: ["Netscape", "Microsoft", "Google", "Oracle"],
      answer: "Netscape"
    },
    {
      question: "Which symbol is used for single-line comments in JavaScript?",
      options: ["<!-- -->", "/* */", "//", "#"],
      answer: "//"
    },
    {
      question: "Which method is used to print something in the browser console?",
      options: ["console.print()", "console.write()", "console.log()", "log.console()"],
      answer: "console.log()"
    },
    {
      question: "Which keyword is used to declare a constant variable?",
      options: ["var", "let", "const", "static"],
      answer: "const"
    },
    {
      question: "What is the default value of an uninitialized variable in JavaScript?",
      options: ["null", "0", "undefined", "NaN"],
      answer: "undefined"
    },
    {
      question: "Which function is used to convert a string into an integer in JavaScript?",
      options: ["parseInt()", "int()", "toInteger()", "Number.parse()"],
      answer: "parseInt()"
    },
    {
      question: "Which operator is used to check both value and type in JavaScript?",
      options: ["==", "=", "===", "!="],
      answer: "==="
    },
    {
      question: "Which object is used for working with dates in JavaScript?",
      options: ["Time", "Date", "Calendar", "Moment"],
      answer: "Date"
    },
    {
      question: "Which method adds a new element to the end of an array?",
      options: ["push()", "pop()", "shift()", "unshift()"],
      answer: "push()"
    },
    {
      question: "Which keyword is used to define a function in JavaScript?",
      options: ["method", "define", "function", "fun"],
      answer: "function"
    }
  ];

  const quizContainer = document.getElementById("quiz");
  const resultContainer = document.getElementById("result");

  // Build quiz
  function buildQuiz() {
    let output = "";
    questions.forEach((q, i) => {
      output += `<p><strong>Q${i+1}:</strong> ${q.question}<br>`;
      q.options.forEach(option => {
        output += `
          <label class="option">
            <input type="radio" name="answer${i}" value="${option}" required> ${option}
          </label>
        `;
      });
      output += `</p>`;
    });
    output += `<button onclick="submitQuiz()">Submit</button>`;
    quizContainer.innerHTML = output;
  }

  // Submit quiz
  function submitQuiz() {
    let score = 0;
    let output = "<h2>Result:</h2>";

    questions.forEach((q, i) => {
      const selected = document.querySelector(`input[name="answer${i}"]:checked`);
      const userAnswer = selected ? selected.value : "";
      output += `<p><strong>Q${i+1}:</strong> ${q.question}<br>`;
      output += `Your Answer: ${userAnswer || "Not Answered"}<br>`;
      if (userAnswer === q.answer) {
        output += `<span class="correct">Correct (+2)</span></p>`;
        score += 2;
      } else {
        output += `<span class="incorrect">Incorrect (0)</span><br>`;
        output += `Correct Answer: ${q.answer}</p>`;
      }
    });

    output += `<h3>Total Score: ${score} / ${questions.length * 2}</h3>`;
    output += `<a href="" onclick="restartQuiz(event)">Try Again</a>`;

    resultContainer.innerHTML = output;
    resultContainer.style.display = "block";
    quizContainer.style.display = "none";
  }

  // Restart quiz
  function restartQuiz(event) {
    event.preventDefault();
    resultContainer.style.display = "none";
    quizContainer.style.display = "block";
    buildQuiz();
  }

  // Start quiz
  buildQuiz();
</script>

</body>
</html>
