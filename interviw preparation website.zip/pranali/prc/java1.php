<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        

function data()
{   
     let name=document.getElementById("name").value;
     let city=document.getElementById("city").value;
     let letters=/^[a-z A-Z]*$/;
     let email=document.getElementById("email").value;
     let mobile=document.getElementById("mobile").value;
     let pass1=document.getElementById("pass1").value;
     let pass2=document.getElementById("pass2").value;

    if(name==""||city==""||email==""||mobile==""||pass1==""||pass2=="")
    {
        alert("plz all value are fullfill");
        return false;
    }
   else if(!name.match(letters))
    {
        alert("enter only character");
        return false;
    }
    else if(!city.match(letters))
    {
        alert("enter only character");
        return false;
    }
    else if(mobile.length<10||mobile.length>10)
    {
        alert("enter 10 digit number");
        return false;
    }
    else if(pass1.length<6||pass1.length>6)
    {
       alert("password should be 6 character");
       return false;
    }
    else if(isNaN(mobile))
    {
       alert("enter only number");
       return false;
    }
    else if(pass1!=pass2)
    {
       alert("enter same password");
       return false;
    }
    else
    {
         true;
    }
  }

</head>

<body>
<form onsubmit="return data()" action="data2.php" method="post">

    <fieldset>
        <h2>create new account</h2>
        <i>USER NAME: </i>
        <input type="text" id="name" placeholder="enter full name" name="name"><br>
        
        <input type="submit" value="SUBMIT" id="submit"> <br><br>

    </fieldset>
</form>
</body>

</html>


</body>
</html>