<?php
// Questions with multiple-choice options (Data Science)
$questions = [
    [
        "question" => "Which of the following is the main goal of Data Science?",
        "options" => ["To clean databases", "To extract insights and knowledge from data", "To replace human intelligence", "To create only visual dashboards"],
        "answer" => "To extract insights and knowledge from data"
    ],
    [
        "question" => "Which programming language is most widely used in Data Science?",
        "options" => ["Python", "Java", "C++", "PHP"],
        "answer" => "Python"
    ],
    [
        "question" => "Which library in Python is used for data manipulation and analysis?",
        "options" => ["NumPy", "Pandas", "Matplotlib", "TensorFlow"],
        "answer" => "Pandas"
    ],
    [
        "question" => "Which of the following is a supervised machine learning algorithm?",
        "options" => ["K-Means", "Linear Regression", "Apriori", "DBSCAN"],
        "answer" => "Linear Regression"
    ],
    [
        "question" => "Which concept is used to split data into training and testing sets?",
        "options" => ["Data Sampling", "Data Cleaning", "Data Partitioning", "Data Joining"],
        "answer" => "Data Partitioning"
    ],
    [
        "question" => "What does NLP stand for in Data Science?",
        "options" => ["Natural Language Processing", "Numeric Linear Programming", "Neural Language Prediction", "Network Layer Protocol"],
        "answer" => "Natural Language Processing"
    ],
    [
        "question" => "Which metric is used to evaluate classification models?",
        "options" => ["Accuracy", "RMSE", "MSE", "Variance"],
        "answer" => "Accuracy"
    ],
    [
        "question" => "Which visualization library is commonly used in Python?",
        "options" => ["Django", "Matplotlib", "Flask", "Pandas"],
        "answer" => "Matplotlib"
    ],
    [
        "question" => "Which type of learning uses labeled data?",
        "options" => ["Supervised Learning", "Unsupervised Learning", "Reinforcement Learning", "Deep Learning"],
        "answer" => "Supervised Learning"
    ],
    [
        "question" => "Which tool is commonly used for big data processing?",
        "options" => ["Excel", "Hadoop", "Flask", "GitHub"],
        "answer" => "Hadoop"
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Data Science Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form, .result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    input[type="submit"] {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    input[type="submit"]:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    echo "<div class='result'>";
    echo "<h2>Result:</h2>";
    foreach ($questions as $i => $q) {
        $userAnswer = $_POST['answer' . $i] ?? '';
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        echo "Your Answer: $userAnswer<br>";
        if ($userAnswer === $q['answer']) {
            echo "<span class='correct'>Correct (+2)</span></p>";
            $score += 2;
        } else {
            echo "<span class='incorrect'>Incorrect (0)</span><br>";
            echo "Correct Answer: {$q['answer']}</p>";
        }
    }
    echo "<h3>Total Score: $score / " . (count($questions) * 2) . "</h3>";
    echo "<a href=''>Try Again</a>";
    echo "</div>";
} else {
    // Show the quiz form
    echo "<h2>Data Science Quiz</h2>";
    echo "<form method='post'>";
    foreach ($questions as $i => $q) {
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        foreach ($q['options'] as $option) {
            echo "<label class='option'>
                    <input type='radio' name='answer$i' value='$option' required> $option
                  </label>";
        }
        echo "</p>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
}
?>

</body>
</html>
