<?php
// Questions with multiple-choice options (SQL Language)
$questions = [
    [
        "question" => "What does SQL stand for?",
        "options" => ["Structured Query Language", "Strong Question Language", "Sequential Query Language", "Stylish Question Language"],
        "answer" => "Structured Query Language"
    ],
    [
        "question" => "Which SQL statement is used to extract data from a database?",
        "options" => ["GET", "SELECT", "EXTRACT", "OPEN"],
        "answer" => "SELECT"
    ],
    [
        "question" => "Which SQL clause is used to filter the records?",
        "options" => ["WHERE", "HAVING", "FILTER", "ORDER BY"],
        "answer" => "WHERE"
    ],
    [
        "question" => "Which SQL keyword is used to sort the result-set?",
        "options" => ["SORT", "ORDER", "ORDER BY", "SORT BY"],
        "answer" => "ORDER BY"
    ],
    [
        "question" => "Which command is used to remove all records from a table but not the table itself?",
        "options" => ["DELETE", "DROP", "TRUNCATE", "REMOVE"],
        "answer" => "TRUNCATE"
    ],
    [
        "question" => "Which operator is used to check multiple conditions in SQL?",
        "options" => ["AND/OR", "IF/ELSE", "FOR/WHILE", "SWITCH"],
        "answer" => "AND/OR"
    ],
    [
        "question" => "Which SQL statement is used to update data in a database?",
        "options" => ["MODIFY", "UPDATE", "CHANGE", "ALTER"],
        "answer" => "UPDATE"
    ],
    [
        "question" => "Which SQL function is used to count the number of rows?",
        "options" => ["COUNT()", "SUM()", "TOTAL()", "NUMBER()"],
        "answer" => "COUNT()"
    ],
    [
        "question" => "Which SQL constraint ensures all values in a column are unique?",
        "options" => ["PRIMARY KEY", "UNIQUE", "FOREIGN KEY", "CHECK"],
        "answer" => "UNIQUE"
    ],
    [
        "question" => "Which SQL keyword is used to combine rows from two or more tables?",
        "options" => ["JOIN", "COMBINE", "MERGE", "LINK"],
        "answer" => "JOIN"
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SQL Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form, .result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    input[type="submit"] {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    input[type="submit"]:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    echo "<div class='result'>";
    echo "<h2>Result:</h2>";
    foreach ($questions as $i => $q) {
        $userAnswer = $_POST['answer' . $i] ?? '';
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        echo "Your Answer: $userAnswer<br>";
        if ($userAnswer === $q['answer']) {
            echo "<span class='correct'>Correct (+2)</span></p>";
            $score += 2;
        } else {
            echo "<span class='incorrect'>Incorrect (0)</span><br>";
            echo "Correct Answer: {$q['answer']}</p>";
        }
    }
    echo "<h3>Total Score: $score / " . (count($questions) * 2) . "</h3>";
    echo "<a href=''>Try Again</a>";
    echo "</div>";
} else {
    // Show the quiz form
    echo "<h2>SQL Quiz</h2>";
    echo "<form method='post'>";
    foreach ($questions as $i => $q) {
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        foreach ($q['options'] as $option) {
            echo "<label class='option'>
                    <input type='radio' name='answer$i' value='$option' required> $option
                  </label>";
        }
        echo "</p>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
}
?>

</body>
</html>
