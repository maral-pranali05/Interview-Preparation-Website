<?php
// Questions with multiple-choice options
$questions = [
    [
        "question" => "Which function is used to output text in PHP?",
        "options" => ["echo", "print", "printf", "All of the above"],
        "answer" => "All of the above"
    ],
    [
        "question" => "Which symbol is used to indicate a variable in PHP?",
        "options" => ["#", "$", "&", "%"],
        "answer" => "$"
    ],
    [
        "question" => "Which superglobal is used to collect form data sent with POST method?",
        "options" => ["$_POST", "$_GET", "$_REQUEST", "$_FORM"],
        "answer" => "$_POST"
    ],
    [
        "question" => "Which function is used to include files in PHP?",
        "options" => ["include()", "require()", "include_once()", "All of the above"],
        "answer" => "All of the above"
    ],
    [
        "question" => "Which operator is used for concatenation in PHP?",
        "options" => ["+", ".", "&", "concat"],
        "answer" => "."
    ],
    [
        "question" => "Which function is used to start a session in PHP?",
        "options" => ["session_start()", "start_session()", "begin_session()", "session_begin()"],
        "answer" => "session_start()"
    ],
    [
        "question" => "Which function is used to check if a variable is set in PHP?",
        "options" => ["isset()", "empty()", "var_check()", "is_set()"],
        "answer" => "isset()"
    ],
    [
        "question" => "Which keyword is used to define a constant in PHP?",
        "options" => ["const", "define", "constant", "All of the above"],
        "answer" => "define"
    ],
    [
        "question" => "Which function is used to remove whitespace from the beginning and end of a string?",
        "options" => ["trim()", "strip()", "strlen()", "chop()"],
        "answer" => "trim()"
    ],
    [
        "question" => "Which function is used to redirect to another page in PHP?",
        "options" => ["header()", "redirect()", "goto()", "location()"],
        "answer" => "header()"
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PHP Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form, .result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    input[type="submit"] {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    input[type="submit"]:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    echo "<div class='result'>";
    echo "<h2>Result:</h2>";
    foreach ($questions as $i => $q) {
        $userAnswer = $_POST['answer' . $i] ?? '';
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        echo "Your Answer: $userAnswer<br>";
        if ($userAnswer === $q['answer']) {
            echo "<span class='correct'>Correct (+2)</span></p>";
            $score += 2;
        } else {
            echo "<span class='incorrect'>Incorrect (0)</span><br>";
            echo "Correct Answer: {$q['answer']}</p>";
        }
    }
    echo "<h3>Total Score: $score / " . (count($questions) * 2) . "</h3>";
    echo "<a href=''>Try Again</a>";
    echo "</div>";
} else {
    // Show the quiz form
    echo "<h2>PHP Quiz</h2>";
    echo "<form method='post'>";
    foreach ($questions as $i => $q) {
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        foreach ($q['options'] as $option) {
            echo "<label class='option'>
                    <input type='radio' name='answer$i' value='$option' required> $option
                  </label>";
        }
        echo "</p>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
}
?>

</body>
</html>
