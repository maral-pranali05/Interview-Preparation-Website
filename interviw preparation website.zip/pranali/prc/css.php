<?php
// Questions with multiple-choice options (CSS Language)
$questions = [
    [
        "question" => "What does CSS stand for?",
        "options" => ["Colorful Style Sheets", "Creative Style System", "Cascading Style Sheets", "Computer Style Sheets"],
        "answer" => "Cascading Style Sheets"
    ],
    [
        "question" => "Which property is used to change the background color in CSS?",
        "options" => ["color", "background-color", "bgcolor", "background"],
        "answer" => "background-color"
    ],
    [
        "question" => "Which CSS property is used to change text color?",
        "options" => ["font-color", "text-color", "color", "foreground-color"],
        "answer" => "color"
    ],
    [
        "question" => "Which CSS property controls the text size?",
        "options" => ["font-style", "text-size", "font-size", "size"],
        "answer" => "font-size"
    ],
    [
        "question" => "How do you select an element with id 'header' in CSS?",
        "options" => [".header", "#header", "header", "*header"],
        "answer" => "#header"
    ],
    [
        "question" => "How do you select elements with class 'container'?",
        "options" => [".container", "#container", "container", "*container"],
        "answer" => ".container"
    ],
    [
        "question" => "Which value of position places an element relative to its first positioned ancestor?",
        "options" => ["fixed", "relative", "absolute", "static"],
        "answer" => "absolute"
    ],
    [
        "question" => "Which property is used to make text bold in CSS?",
        "options" => ["font-style", "font-weight", "text-bold", "style"],
        "answer" => "font-weight"
    ],
    [
        "question" => "Which property is used to add space inside an element’s border?",
        "options" => ["margin", "spacing", "padding", "border-spacing"],
        "answer" => "padding"
    ],
    [
        "question" => "Which CSS property is used to change the cursor to a pointer (hand icon)?",
        "options" => ["cursor", "pointer", "mouse", "cursor-type"],
        "answer" => "cursor"
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSS Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form, .result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    input[type="submit"] {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    input[type="submit"]:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    echo "<div class='result'>";
    echo "<h2>Result:</h2>";
    foreach ($questions as $i => $q) {
        $userAnswer = $_POST['answer' . $i] ?? '';
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        echo "Your Answer: $userAnswer<br>";
        if ($userAnswer === $q['answer']) {
            echo "<span class='correct'>Correct (+2)</span></p>";
            $score += 2;
        } else {
            echo "<span class='incorrect'>Incorrect (0)</span><br>";
            echo "Correct Answer: {$q['answer']}</p>";
        }
    }
    echo "<h3>Total Score: $score / " . (count($questions) * 2) . "</h3>";
    echo "<a href=''>Try Again</a>";
    echo "</div>";
} else {
    // Show the quiz form
    echo "<h2>CSS Quiz</h2>";
    echo "<form method='post'>";
    foreach ($questions as $i => $q) {
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        foreach ($q['options'] as $option) {
            echo "<label class='option'>
                    <input type='radio' name='answer$i' value='$option' required> $option
                  </label>";
        }
        echo "</p>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
}
?>

</body>
</html>
