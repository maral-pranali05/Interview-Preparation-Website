<?php
// Questions with multiple-choice options
$questions = [
    [
        "question" => "What is the size of int in Java?",
        "options" => ["2", "4", "8", "16"],
        "answer" => "4"
    ],
    [
        "question" => "Which keyword is used to inherit a class in Java?",
        "options" => ["this", "super", "extends", "implements"],
        "answer" => "extends"
    ],
    [
        "question" => "Which method is the entry point of a Java program?",
        "options" => ["start", "run", "main", "execute"],
        "answer" => "main"
    ],
    [
        "question" => "What is the superclass of all classes in Java?",
        "options" => ["Class", "Object", "Base", "Parent"],
        "answer" => "Object"
    ],
    [
        "question" => "Which keyword is used to create an object in Java?",
        "options" => ["create", "object", "new", "instance"],
        "answer" => "new"
    ],
    [
        "question" => "Which exception is thrown when a divide by zero occurs?",
        "options" => ["IOException", "NullPointerException", "ArithmeticException", "DivideByZero"],
        "answer" => "ArithmeticException"
    ],
    [
        "question" => "Which loop is guaranteed to execute at least once?",
        "options" => ["for", "while", "do-while", "foreach"],
        "answer" => "do-while"
    ],
    [
        "question" => "What is used to handle exceptions in Java?",
        "options" => ["try-catch", "if-else", "throw", "assert"],
        "answer" => "try-catch"
    ],
    [
        "question" => "Which package contains Scanner class?",
        "options" => ["java.lang", "java.io", "java.util", "java.net"],
        "answer" => "java.util"
    ],
    [
        "question" => "Which operator is used for comparison in Java?",
        "options" => ["=", "==", "===", "!="],
        "answer" => "=="
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Java Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fa;
      margin: 0;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form, .result {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
    }
    p {
      margin-bottom: 15px;
    }
    .option {
      margin: 5px 0;
      display: block;
    }
    input[type="submit"] {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    input[type="submit"]:hover {
      background: #0056b3;
    }
    .correct {
      color: green;
      font-weight: bold;
    }
    .incorrect {
      color: red;
      font-weight: bold;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    echo "<div class='result'>";
    echo "<h2>Result:</h2>";
    foreach ($questions as $i => $q) {
        $userAnswer = $_POST['answer' . $i] ?? '';
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        echo "Your Answer: $userAnswer<br>";
        if ($userAnswer === $q['answer']) {
            echo "<span class='correct'>Correct (+2)</span></p>";
            $score += 2;
        } else {
            echo "<span class='incorrect'>Incorrect (0)</span><br>";
            echo "Correct Answer: {$q['answer']}</p>";
        }
    }
    echo "<h3>Total Score: $score / " . (count($questions) * 2) . "</h3>";
    echo "<a href=''>Try Again</a>";
    echo "</div>";
} else {
    // Show the quiz form
    echo "<h2>Java Quiz</h2>";
    echo "<form method='post'>";
    foreach ($questions as $i => $q) {
        echo "<p><strong>Q" . ($i + 1) . ":</strong> {$q['question']}<br>";
        foreach ($q['options'] as $option) {
            echo "<label class='option'>
                    <input type='radio' name='answer$i' value='$option' required> $option
                  </label>";
        }
        echo "</p>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
}
?>

</body>
</html>
