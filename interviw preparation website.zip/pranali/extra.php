<?php
// extra.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aptitude Videos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f9f9f9;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .video-container {
            margin: 20px auto;
            max-width: 560px;
        }
        iframe {
            width: 100%;
            height: 315px;
            border: none;
        }
    </style>
</head>
<body>
    <h1>Aptitude Video Tutorials</h1>

    <div class="video-container">
        <iframe src="https://www.youtube.com/embed/rjCmGhY6cYQ" allowfullscreen></iframe>
        <p>Basic Aptitude Questions</p>
    </div>

    <div class="video-container">
        <iframe src="https://www.youtube.com/embed/DoEx_zK_2Vc" allowfullscreen></iframe>
        <p>Advanced Aptitude Tricks</p>
    </div>

    <div class="video-container">
        <iframe src="https://www.youtube.com/embed/KSeIr93uxjk" allowfullscreen></iframe>
        <p>Quantitative Aptitude Tips</p>
    </div>
    <div class="video-container">
        <iframe src="https://www.youtube.com/embed/dHvN09pxRqc" allowfullscreen></iframe>
        <p>Quantitative Aptitude Tips</p>
    </div>
    <div class="video-container">
        <iframe src="https://www.youtube.com/embed/rhZUX-P1hAI" allowfullscreen></iframe>
        <p>Quantitative Aptitude Tips</p>
    </div>

</body>
</html>
