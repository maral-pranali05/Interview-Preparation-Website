<!DOCTYPE html>

<head>
    <style>
        * {
            background-color: #ffffff;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 120vh;
            margin: 0;
        }
        
        form {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            max-width: 400px;
            box-shadow: 0px 0px 10px rgb(127, 114, 241);
            width: 100%;
        }
        
        fieldset {
            border: none;
        }
        
        h2 {
            margin-bottom: 30px;
            text-align: center;
            color: #333;
        }
        
        i {
            font-style: normal;
            font-weight: bold;
            color: #555;
            font-size: 15px;
        }
        
        input {
            border: 0.5px solid;
        }
        
        input:focus {
            border: 5px solid darkblue;
            outline: 1px solid darkblue;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 2px 0 10px 0;
            border: 1px solid rgb(222, 216, 216);
            border-radius: 5px;
            font-size: 14px;
        }
        
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        
        input[type="submit"] {
             background: #5F9EA0;
            color: white;
        }
        
        input[type="submit"]:hover {
             background: #5F9EA0;
        }
    </style>
    <script>
        

function data()
{   
     let name=document.getElementById("name").value;
     let city=document.getElementById("city").value;
     let letters=/^[a-z A-Z]*$/;
     let email=document.getElementById("email").value;
     let mobile=document.getElementById("mobile").value;
     let pass1=document.getElementById("pass1").value;
     let pass2=document.getElementById("pass2").value;

    if(name==""||city==""||email==""||mobile==""||pass1==""||pass2=="")
    {
        alert("plz all value are fullfill");
        return false;
    }
   else if(!name.match(letters))
    {
        alert("enter only character");
        return false;
    }
    else if(!city.match(letters))
    {
        alert("enter only character");
        return false;
    }
    else if(mobile.length<10||mobile.length>10)
    {
        alert("enter 10 digit number");
        return false;
    }
    else if(pass1.length<6||pass1.length>6)
    {
       alert("password should be 6 character");
       return false;
    }
    else if(isNaN(mobile))
    {
       alert("enter only number");
       return false;
    }
    else if(pass1!=pass2)
    {
       alert("enter same password");
       return false;
    }
    else
    {
         true;
    }
  }
</script>

</script>
</head>

<body>
<form onsubmit="return data()" action="data2.php" method="post">

    <fieldset>
        <h2>create new account</h2>
        <i>USER NAME: </i>
        <input type="text" id="name" placeholder="enter full name" name="name"><br>
        <i> CITY NAME:</i><br>
        <input type="text" id="city" placeholder="enter city" name="city"><br>
        <i> EMAIL ID: </i><br>
        <input type="email" id="email" placeholder="enter email" name="email"><br>
        <i> MOBILE NO:</i>
        <input type="text" id="mobile" placeholder="enter mobile no:" name="mobile"><br>
        <i> PASSWORD:</i>
        <input type="password" id="pass1" placeholder="password" name="pass1"><br><br>
        <i>CONFIRM PASSWORD:</i>
        <input type="password" id="pass2" placeholder="password" name="pass2"><br><br>
        <input type="submit" value="SUBMIT" id="submit"> <br><br>

    </fieldset>
</form>
</body>

</html>

