<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <style>
    *{
    margin: 0;
    padding:0;
    box-sizing: border-box;
    font-family:sans-serif;
}
nav
{
width: 100%;
height: 75px;
line-height: 75px;
padding: 0px 100px;
background-image: linear-gradient(#040317,#012733);
}

nav .logo p
{
font-size: 30px;
font-weight: bold;
float: left;
color: white;
text-transform: uppercase;
letter-spacing: 1.5px;
cursor: pointer;
}
nav ul{
    float: right;
    margin-right: 50px;
    
}
nav ul li{
    display: inline-block;
    margin:0 15px;
    cursor: pointer;
    font-size: 17px;
    text-transform: uppercase;  
}
nav ul li a{
    text-decoration: none;
    color:white;
}
 ul li a:hover{
    background:white;
    color:black;
    transition: .5s;
    border-radius: 2px;


}
.home img
{
    
    position: relative;
    width:100%;
    justify-content: space-between;
    height: 100vh;
    display: flex;
    align-items: center;
    padding: 70px 0% 0;
    margin-top: 0px;
    padding-top: 0px;
}
.carousel-item .carousel-caption
{
    
    align-items: center;
    justify-content: center;
    color:white;
    margin-bottom: 250px;
   
   
}
.carousel-caption h3{
    color:white;
    font-family: serif;
    margin-bottom: 20px;
    font-weight:bolder ;
    letter-spacing: 1.5px;

}
.carousel-caption h5
{
    font-weight: bold;
}
.carousel-item img{
    opacity: 1;
}
.second {
    width: 100%;
    height: 42px;
    background-color: rgb(10, 10, 58);
    display: flex;
    align-items: center;
    color: #fffd;
    overflow: hidden;
}
.container0,.container1,.container2 {
    display: flex;
   width: 150%;
    margin-left: auto;
    margin-right: auto;
}

.box {
    width: 20%;
    float: left;
    background-color: white;
    border-radius: 5px;
    box-shadow: 0 7px 7px grey;
    margin: 40px 20px;
}

.box img {
    width: 100%;
    height: 250px;
    border-radius: 5px 5px 0 0;


}

.box h3 {
    margin-left: 10px;
    line-height: 25px;
    height: 15%;
    padding: 10px 15px 15px 15px;
    overflow: hidden;
    margin-top: 30px;
    font-size: 20px;
    font-family: sans-serif;
}


.box a{
    background-color: teal;
    color: white;
    padding: 10px 15px;
    margin: 25px;
    border-radius: 5px;
    float: right;
    text-decoration: none;
}

.box a:hover 
{
    background-color:rgb(59, 147, 176);
    box-shadow: 0 5px 5px rgba(0, 0, 0, 0.2);

}
footer
{
    background-color:black;
    height: auto;
    width: 100vw;
    padding-top: 40px;
    color: white;
}
.footer-content
{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
}
.footer-content h3
{
    font-size: 1.8rem;
    font-weight: 400;
    text-transform: capitalize;
    line-height: 3rem;
}

.footer-content p
{
    max-width: 500px;
    margin: 10px auto;
    line-height: 28px;

    font-size: 14px;
}
.social{
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1rem 0 3 rem 0;
}
.social li
{
    margin: 0,10px;
}
.social a{
    text-decoration: none;
    color: #fff;
}
.social li a{
    font-size: 1.1rem;
    transition: color .4s ease;
    margin: 3px 10px;
}
.social a:hover i{
    color: aqua;

}
.footer-bottom{
    background:black;
    width: 100vw;
    padding: 20px 0;
    text-align: center;
}
.footer-bottom p{
    font-size: 14px;
    word-break: 2px;
    text-transform: capitalize;
  
}
.footer-bottom span{
    text-transform: uppercase;
    opacity: .4;
    font-weight: 200;
}

    </style>
</head>


  
</head>

<body>
<header>
  <nav class="navbar">
    <div class="logo">
      <p>code master</p>
    </div>
      <ul>
        <li><a href="index.php">About As</a></li>
        <li><a href="index.php">interview question</a></li>
        <li><a href="#footer">contact us</a></li>
        <li><a href="index.php">Home</a></li>

      </ul>
    
  </nav>
  <style>
     h2
     {
      
      margin-left :460px;
      padding-top :20px;
     }
  </style>

</header>

  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  <div class="main" id="interview">
    <h2>Top Programming Language</h2>
    <div class="container0">
      <div class="box">
        <img src="image\java.jpg">
        <h3><b>Top 20 JAVA Interview Question And Answer</b></h3>
        <a href="prc/java.php">LET'S PRACTICE</a>
      </div>

      <div class="box">
        <img src="image\C.jpg">
        <h3><b>Top 20 C Interview Question And Answer</b></h3>
        <a href="prc/c.php">LET'S PRACTICE</a>
      </div>

      <div class="box">
        <img src="image\python.jpg">
        <h3><b>Top 20 PYTHON Interview Question And Answer</b></h3>
        <a href="prc/python.php">LET'S PRACTICE</a>
      </div>
    </div>


    <div class="container1">

      <div class="box">
        <img src="image\html.jpg">
        <h3><b>Top 20 HTML Interview Question And Answer</b></h3>
        <a href="prc/html.php">LET'S PRACTICE</a>
      </div>


      <div class="box">
        <img src="image\css.jpg">
        <h3><b> Top 20 CSS Interview Question And Answer </b></h3>
        <a href="prc/css.php">LET'S PRACTICE</a>
      </div>

      <div class="box">
        <img src="image\sql.jpg">
        <h3><b> Top 20 SQL Interview Question And Answer</b></h3>
        <a href="prc/sql.php">LET'S PRACTICE</a>
      </div>

    </div>
    <div class="container2">

      <div class="box">
        <img src="image\ds.jpg">
        <h3><b>Top 20 DATA SCIENCE Interview Question And Answer</b></h3>
        <a href="prc/data_scince.php">LET'S PRACTICE</a>
      </div>

      <div class="box">
        <img src="image\js.jpg">
        <h3><b>Top 20 JAVA SCRIPT Interview Question And Answer</b></h3>
        <a href="prc/js.php">LET'S PRACTICE</a>

      </div>
      <div class="box">
        <img src="image\php.jpg">
        <h3><b> Top 20 PHP Interview Questions And Answers</b></h3>
        <a href="prc/php.php">LET'S PRACTICE</a>
      </div>
    </div>

  </div>

  
  
  <footer id="footer">

    <div class="footer-content">
      <h3>Code master</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo officia
        adipisci eaque, dolores hic minus facere. Excepturi provident corporis optio.
      </p>
      <ul class="social">
        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
        <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>

      </ul>
    </div>
    <div class="footer-bottom">
      <p>copyright &copy;2020 codeopecity. designed by <span>omkar & pranali</span></p>
    </div>

  </footer>

</body>

</html>